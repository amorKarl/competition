CREATE VIEW `v_trades_detail` AS
  SELECT
    `competition`.`t_users`.`name`                 AS `name`,
    `competition`.`t_users`.`repuation`            AS `repuation`,
    `competition`.`t_trades_publish`.`trade_money` AS `trade_money`,
    `competition`.`t_trades_publish`.`start_time`  AS `start_time`,
    `competition`.`t_trades_screen`.`screen`       AS `screen`,
    `competition`.`t_users`.`username`             AS `username`,
    `competition`.`t_trades_publish`.`id`          AS `trade_id`
  FROM ((`competition`.`t_users`
    JOIN `competition`.`t_trades_publish`
      ON ((`competition`.`t_trades_publish`.`initiator` = `competition`.`t_users`.`id`))) JOIN
    `competition`.`t_trades_screen`
      ON ((`competition`.`t_trades_publish`.`screen_id` = `competition`.`t_trades_screen`.`id`)))