CREATE VIEW `v_topic_discuss` AS
  SELECT
    `competition`.`t_topics_discuss`.`id`        AS `id`,
    `competition`.`t_topics_discuss`.`topic`     AS `topic`,
    `competition`.`t_topics_discuss`.`content`   AS `content`,
    `competition`.`t_topics_discuss`.`user_id`   AS `user_id`,
    `competition`.`t_topics_discuss`.`talk_time` AS `talk_time`,
    `competition`.`t_users`.`name`               AS `name`,
    `competition`.`t_users`.`icon`               AS `icon`
  FROM (`competition`.`t_topics_discuss`
    JOIN `competition`.`t_users` ON ((`competition`.`t_topics_discuss`.`user_id` = `competition`.`t_users`.`id`)))