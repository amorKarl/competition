CREATE VIEW `v_topic_publish` AS
  SELECT
    `competition`.`t_topics_publish`.`id`         AS `id`,
    `competition`.`t_topics_publish`.`title`      AS `title`,
    `competition`.`t_topics_publish`.`content`    AS `content`,
    `competition`.`t_topics_publish`.`start_time` AS `start_time`,
    `competition`.`t_topics`.`type`               AS `type`,
    `competition`.`t_users`.`username`            AS `publish_account`,
    `competition`.`t_users`.`name`                AS `publish_name`,
    `competition`.`t_topics_publish`.`comment`    AS `comment`,
    `competition`.`t_users`.`icon`                AS `icon`,
    `competition`.`t_topics_publish`.`good`       AS `good`
  FROM ((`competition`.`t_topics_publish`
    JOIN `competition`.`t_topics` ON ((`competition`.`t_topics_publish`.`type` = `competition`.`t_topics`.`id`))) JOIN
    `competition`.`t_users` ON ((`competition`.`t_topics_publish`.`publisher_id` = `competition`.`t_users`.`id`)))