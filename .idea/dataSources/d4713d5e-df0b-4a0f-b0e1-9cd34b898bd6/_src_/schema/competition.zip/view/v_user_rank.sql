CREATE VIEW `v_user_rank` AS
  SELECT
    `competition`.`t_trades_publish`.`id`          AS `id`,
    `competition`.`t_users`.`username`             AS `username`,
    `competition`.`t_users`.`name`                 AS `name`,
    `competition`.`t_users`.`icon`                 AS `icon`,
    `competition`.`t_users`.`repuation`            AS `repuation`,
    `competition`.`t_trades_publish`.`trade_money` AS `trade_money`,
    `competition`.`t_trades_publish`.`message`     AS `message`
  FROM (`competition`.`t_users`
    JOIN `competition`.`t_trades_publish`
      ON ((`competition`.`t_trades_publish`.`initiator` = `competition`.`t_users`.`id`)))