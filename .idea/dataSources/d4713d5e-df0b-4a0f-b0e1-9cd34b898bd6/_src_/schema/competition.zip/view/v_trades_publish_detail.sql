CREATE VIEW `v_trades_publish_detail` AS
  SELECT
    `competition`.`t_trades_record`.`purchaser`            AS `purchaser`,
    `competition`.`t_trades_record`.`trade_id`             AS `trade_id`,
    `competition`.`t_trades_record`.`start_time`           AS `start_time`,
    `competition`.`t_trades_record`.`end_time`             AS `end_time`,
    `competition`.`t_trades_record`.`id`                   AS `id`,
    `competition`.`t_trades_publish`.`trade_money`         AS `trade_money`,
    `competition`.`t_trades_publish`.`zhukehe`             AS `zhukehe`,
    `competition`.`t_trades_publish`.`banchangzhukehe`     AS `banchangzhukehe`,
    `competition`.`t_trades_publish`.`rangqiuzhukehe`      AS `rangqiuzhukehe`,
    `competition`.`t_trades_publish`.`rangqiu`             AS `rangqiu`,
    `competition`.`t_trades_publish`.`rangqiudaxi`         AS `rangqiudaxi`,
    `competition`.`t_trades_publish`.`banchangrangqiudaxi` AS `banchangrangqiudaxi`,
    `competition`.`t_trades_publish`.`jiaoqiudaxi`         AS `jiaoqiudaxi`,
    `competition`.`t_trades_publish`.`bodan`               AS `bodan`,
    `competition`.`t_trades_publish`.`banchangbodan`       AS `banchangbodan`,
    `competition`.`t_trades_publish`.`diyiqiuruqiu`        AS `diyiqiuruqiu`,
    `competition`.`t_trades_publish`.`zongruqiu`           AS `zongruqiu`,
    `competition`.`t_trades_publish`.`ruqiudanshuang`      AS `ruqiudanshuang`,
    `competition`.`t_trades_publish`.`banquanchang`        AS `banquanchang`,
    `competition`.`t_trades_publish`.`screen`              AS `screen`,
    `competition`.`t_trades_publish`.`message`             AS `message`,
    `competition`.`t_trades_publish`.`initiator`           AS `initiator`
  FROM (`competition`.`t_trades_publish`
    JOIN `competition`.`t_trades_record`
      ON ((`competition`.`t_trades_record`.`trade_id` = `competition`.`t_trades_publish`.`id`)))